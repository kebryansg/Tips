# array_column() Changelog

## 1.1.3

_Released 2015-03-20_

* Changing package name from "rhumsaa/array_column" to "ramsey/array_column"
* Updated Travis CI build config to test more versions of PHP
* Updated Travis CI config to lint and check PSR-2 coding standards
* Added project badges
* Added CHANGELOG

## 1.1.2

_Released 2013-07-22_

* Remove unnecessary conditionals
* Whitespace changes

## 1.1.1

_Released 2013-07-06_

* Documentation updates

## 1.1.0

_Released 2013-07-06_

* Catching up array_column() library functionality and tests with PHP 5.5.0
* Set Travis CI to run tests on PHP 5.5

## 1.0.0

_Released 2013-03-22_

* Initial release of userland library
